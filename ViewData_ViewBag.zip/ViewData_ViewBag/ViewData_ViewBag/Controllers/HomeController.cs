using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using ViewData_ViewBag.Models;

namespace ViewData_ViewBag.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }
        public ViewResult Details()
        {
            //String string Data
            //ViewData["Title"] = "Student Details Page";
            //ViewData["Header"] = "Student Details";

            //ViewBag.Title = "Student Details Page";
           // ViewBag.Header = "Student Details";

            //Student student = new Student()
            //{
            //    StudentId = 101,
            //    Name = "James",
            //    Branch = "CSE",
            //    Section = "A",
            //    Gender = "Male"
            //};
            Student student = new Student()
            {
                StudentId = 101,
                Name = "Dillip",
                Branch = "CSE",
                Section = "A",
                Gender = "Male"
            };
            //Student Address
            Address address = new Address()
            {
                StudentId = 101,
                City = "Mumbai",
                State = "Maharashtra",
                Country = "India",
                Pin = "400097"
            };
            StudentDetailsViewModel studentDetailsViewModel = new StudentDetailsViewModel()
            {
                Student = student,
                Address = address,
                Title = "Student Details Page",
                Header = "Student Details",
            };

            //storing Student Data
            // ViewData["Student"] = student;
            //ViewBag.student = student;


            return View(studentDetailsViewModel);
        }
            public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
