﻿using System.ComponentModel.DataAnnotations;

namespace ASPIdentityDemo.Models
{
    public class CreateRoleViewModel
    {
        [Required]
        [Display(Name = "Role")]
        public string RoleName { get; set; }
    }
}
