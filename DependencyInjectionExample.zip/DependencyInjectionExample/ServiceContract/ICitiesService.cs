﻿namespace ServiceContract
{
    public interface ICitiesService
    {
        List<string> GetCities();
    }
}
