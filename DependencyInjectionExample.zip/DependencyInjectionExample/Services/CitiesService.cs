﻿using ServiceContract;

namespace Services
{
    public class CitiesService:ICitiesService
    {
        List<string> _cities;

        public CitiesService()
        {
            _cities = new List<string>()
            {
                "Mumbai",
                "Pune",
                "Nasik",
                "Nagpur",
                "Solapur"

            };
        }
        public List<string> GetCities()
        {
            return _cities;
        }
    }
}
