﻿using Microsoft.AspNetCore.Mvc;

namespace EnvironmentDemo.Controllers
{
    public class HomeController : Controller
    {
        private readonly IWebHostEnvironment _HostEnv;

        public HomeController(IWebHostEnvironment env)
        {
            _HostEnv = env;
        }

  
        
        [Route("/")]
        [Route("test-route1")]
        public IActionResult Index()
        {
            if(_HostEnv.IsDevelopment())
            {

            }
            return View();
        }

        [Route("test-route")]
        public IActionResult Other()
        {
            return View();
        }



    }
}
