using ActionResultsExample2.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace ActionResultsExample2.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }
        
        //public RedirectToActionResult Index()
        //{
        //    // return new RedirectResult("https://getbootstrap.com/");
        //    //return  Redirect("https://learn.microsoft.com/aspnet/core");          
        //    //return Redirect("https://localhost:7200/Home/Privacy");
        //    // return View();

        //    //return RedirectToAction("About", "Home");
        //    // return RedirectToAction("About", "Home", new { id = 123, name = "Index" });

        //    var routeValues = new { id = 123, name = "Test" };
        //    var redirectResult = new RedirectToActionResult(
        //        actionName: "About",          // The action to redirect to
        //        controllerName: "Home",       // The controller to redirect to
        //        routeValues: routeValues,     // The route values to pass to the action
        //        permanent: false,             // Indicates if the redirect is permanent (HTTP 301) 302 for temporary
        //        preserveMethod: true,         // Indicates if the HTTP method should be preserved
        //        fragment: "AboutSection"       //Indicates the URL Fragment, i.e., append in the URL as #AboutSection
        //    );
        //    return redirectResult;
        //}

        public IActionResult Index()
        {
            // return RedirectToRoute(new { controller = "Home", action = "About", name = "Index" });     
            //return RedirectToRoute("AboutRoute");

            //var routeValues = new { controller = "Home", action = "About", id = 123, name = "test" };
            //var redirectResult = new RedirectToRouteResult(
            //        routeName: null,          // No specific route name
            //        routeValues: routeValues, // Route values defined earlier
            //        permanent: false,         // Temporary redirection
            //        fragment: "AboutSection"  // URL fragment identifier
            //    );
            //return redirectResult;
            return View();
            
        }

        //NotStatusCodeResult
        public IActionResult NotFoundExample()
        {
            // Return a 404 Not Found response
            //return new StatusCodeResult(404);
            return StatusCode(404, new { message = "Resource Not Found" });
        }

        public IActionResult UnauthorizedExample()
        {
            // Return a 401 Unauthorized response
            //return new UnauthorizedResult();
            // Or use the shorthand helper method:
            //return Unauthorized();

            // Return a 401 Unauthorized response
            return Unauthorized(new { Message = "You Have Not Access to This Page" });
        }

        public IActionResult OkExample()
        {
            // Return a 200 OK response
            //return new OkResult();
            //// Or use the shorthand:
             //return Ok(); 

            // Return a 200 OK response along with Custom Message
            var data = new { Message = "Success" };
            // Returns a JSON object with a 200 OK response
            return Ok(data);
        }

        public ObjectResult GetPerson()
        {
            //var person = new { FirstName = "Pranaya", LastName = "Patil", Age = 40 };
            // Return an ObjectResult with JSON serialization
            // return new ObjectResult(person);
            // Or use the shorthand:
            // return Ok(person);

            var person = new { FirstName = "Pranaya", LastName = "Patil", Age = 37 };
            var result = new ObjectResult(person)
            {
                StatusCode = 200, // HTTP status code
                ContentTypes = new Microsoft.AspNetCore.Mvc.Formatters.MediaTypeCollection
                {
                    "application/json" // Content type(s)
                }
            };
            return result;

            //var person = new { FirstName = "Pranaya", LastName = "Rout", Age = 35 };
            //// Return a 200 OK response with JSON serialization
            //return Ok(person);
        }

        public EmptyResult ProcessRequest()
        {
            // Perform some processing
            // Return an empty HTTP response
            return new EmptyResult();
        }
        public IActionResult DeleteResource()
        {
            // Delete the resource
            // Return a 204 No Content response with an EmptyResult
            return NoContent();
        }

        public IActionResult Privacy()
        {
            return View();
        }
        // public string About(int id,string name)
        public string About(int id,string name)
        {
           return $"Hello welcome {id} & {name}";
          // return View();
        }





        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
