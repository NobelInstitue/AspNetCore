﻿using Microsoft.AspNetCore.Mvc;

namespace ActionResultsExample2.Controllers
{
    public class ProductController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
