using ActionFilterExample.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace ActionFilterExample.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }
        //[CustomActionFilterAttribute]
        //[CustomExceptionFilter]
        [CustomActionFilterAttribute]
        public IActionResult Index()
        { 
            //int x = 10;
            //int y = 0;
            //int z = x / y;
            return View();
        }
        //[CustomResultFilter]
        [RedirectToErrorViewFilter]
        public IActionResult Privacy()
        {
            throw new UnauthorizedAccessException("Access Denied.");
           // return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
