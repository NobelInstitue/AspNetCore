﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ActionConstraints;
using Microsoft.AspNetCore.Mvc.Filters;
using System.Diagnostics;

namespace ActionFilterExample.Models
{
    public class CustomActionFilterAttribute: ActionFilterAttribute
    {
        private Stopwatch _timer;
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            // Initialize and start the timer
            _timer = Stopwatch.StartNew();


            if (context.HttpContext.Request.Query.ContainsKey("admin"))
            {
                context.Result = new ViewResult
                {
                    ViewName = "AdminView",
                   // ViewData = "This is Admin view data",
                   // TempData = viewResult.TempData
                };
            }


            //if( context.RouteContext.HttpContext.Request.Query.ContainsKey("admin"))
            // {

            // }
            // Add a custom header before executing the result
            // context.HttpContext.Response.Headers.Append("X-Pre-Execute", "Header set before execution");
            // Example: Modify the result based on authorization (dummy condition here)
            //if (context.HttpContext.Request.Query.ContainsKey("admin") && context.Result is ViewResult viewResult)
            //{
            //    context.Result = new ViewResult
            //    {
            //        ViewName = "AdminView",
            //        ViewData = viewResult.ViewData,
            //        TempData = viewResult.TempData
            //    };
            //}
            base.OnActionExecuting(context);
        }
        //public override void OnActionExecuted(ActionConstraintContext context)
        //{
        //    _timer.Stop();
        //    var actionName = context.Candidates;
        //    var executionTime = _timer.ElapsedMilliseconds;
        //    var resultType = context.ToString();
        //    // Log details about the action execution
        //    Debug.WriteLine($"Action '{actionName}' executed in {executionTime} ms, resulting in {resultType}");
        //    base.OnActionExecuted(context);
        //}
    }
}
