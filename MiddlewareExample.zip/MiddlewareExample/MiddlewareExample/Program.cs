using MiddlewareExample;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddTransient<MyCustomMiddleware>();
var app = builder.Build();

//app.Run(async (HttpContext context) =>
//{
//    await context.Response.WriteAsync("Hello world");
//});

app.Use(async (HttpContext context, RequestDelegate next) =>
{
    await context.Response.WriteAsync("This is first middleware\n ");
    await next(context);
});
//app.UseMiddleware<MyCustomMiddleware>();
//app.UseMiddleware<Middleware>();
app.UseMiddlewareEx();

app.Use(async (HttpContext context, RequestDelegate next) =>
{
    await context.Response.WriteAsync("This is Third middleware\n ");
    await next(context);
});

//app.Run(async (HttpContext context) =>
//{
//    await context.Response.WriteAsync("This is last middleware");
//});

app.Run();
