﻿
namespace MiddlewareExample
{
    public class MyCustomMiddleware : IMiddleware
    {
        public async Task InvokeAsync(HttpContext context, RequestDelegate next)
        {
            await context.Response.WriteAsync("This is second middleware -start");
            await next(context);
            await context.Response.WriteAsync("This is second middleware-end ");
        }
    }
}
