﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;

namespace MiddlewareExample
{
    // You may need to install the Microsoft.AspNetCore.Http.Abstractions package into your project
    public class MiddlewareEx
    {
        private readonly RequestDelegate _next;

        public MiddlewareEx(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext httpContext)
        {
            await httpContext.Response.WriteAsync("This is start");
            await _next(httpContext);
            await httpContext.Response.WriteAsync("This is end ");

           // return _next(httpContext);
        }
    }

    // Extension method used to add the middleware to the HTTP request pipeline.
    public static class MiddlewareExExtensions
    {
        public static IApplicationBuilder UseMiddlewareEx(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<MiddlewareEx>();
        }
    }
}
