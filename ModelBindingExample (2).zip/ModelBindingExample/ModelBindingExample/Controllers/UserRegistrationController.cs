﻿using Microsoft.AspNetCore.Mvc;
using ModelBindingExample.Models;

namespace ModelBindingExample.Controllers
{
    public class UserRegistrationController : Controller
    {
        public IActionResult Index()
        {
            var model = new User();
            ViewBag.Countries = new List<string> { "United States", "Canada", "United Kingdom", "Australia", "India" };
            ViewBag.Hobbies = new List<string> { "Reading", "Traveling", "Gaming", "Cooking" };
            return View(model);

        }

        [HttpPost]
        public IActionResult Index([FromForm] User user)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Countries = new List<string> { "United States", "Canada", "United Kingdom", "Australia", "India" };
                ViewBag.Hobbies = new List<string> { "Reading", "Traveling", "Gaming", "Cooking" };
                return View(user);
            }
            return RedirectToAction("Success", user);
        }

        [HttpGet]
        public IActionResult Success(User user)
        {
            return View(user);
        }
    }
}
