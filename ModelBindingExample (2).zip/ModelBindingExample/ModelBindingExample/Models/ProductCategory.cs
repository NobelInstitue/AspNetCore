﻿namespace ModelBindingExample.Models
{
    public enum ProductCategory
    {
        Electronics,
        Accessories,
        Computers,
        SmartHome,
        Wearables,
        Cameras,
        Gaming,
        HomeEntertainment,
        Audio
    }
}
