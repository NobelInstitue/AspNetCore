﻿using ActionResultExample.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace ActionResultExample.Controllers
{
    public class EmployeeController : Controller
    {
        //Partial view
        //public PartialViewResult Index()
        //{
        //    return PartialView("_EmployeeInfoPartialView");
        //}

        public IActionResult Index()
        {
            return View();
        }
        //Json Result
        //public JsonResult Index()
        //{
        //    //Student student = new Student()
        //    //{
        //    //     Id = 1,
        //    //     Name = "Test",                
        //    // };
        //    var Employee = new[]
        //    {
        //        new { Name = "Pranaya", Age = 25, Occupation = "Designer" },
        //        new { Name = "Ramesh", Age = 30, Occupation = "Manager" }
        //    };

        //    return Json(Employee);     

        //}

        //public ContentResult Index()
        //{

        //    //string content = "This is a simple string.";
        //    //return Content(content);

        //    //string htmlContent = "<html><body><h1>Hello, Welcome </h1></body></html>";
        //    //return Content(htmlContent, "text/html");

        //    //string xmlContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><data><item>This is content result</item></data>";
        //    //return Content(xmlContent, "application/xml");

        //    var jsonData = new { Name = "Pranaya", Age = 35, Occupation = "Manager" };
        //    var jsonSerializedString = JsonConvert.SerializeObject(jsonData);
        //    return Content(jsonSerializedString, "application/json");

        //}


        public PhysicalFileResult DownloadFile()
        {
            //string filePath = Directory.GetCurrentDirectory() + "\\wwwroot\\PDFFiles\\" + "Sample.pdf";
            //var fileBytes = System.IO.File.ReadAllBytes(filePath);
            //var fileResult = File(fileBytes, "application/pdf");
            //fileResult.FileDownloadName = "MySampleFile.pdf";
            //return fileResult;


            //string filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "PDFFiles", "Sample.pdf");
            //var fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
            //var fileResult = new FileStreamResult(fileStream, "application/pdf")
            //{
            //    FileDownloadName = "MySampleFile.pdf",
            //    LastModified = new DateTimeOffset(System.IO.File.GetLastWriteTimeUtc(filePath)),
            //};
            //return fileResult;


            //Virtual File result
            //string virtualFilePath = "/PDFFiles/Sample.pdf";
            //var fileResult = new VirtualFileResult(virtualFilePath, "application/pdf")
            //{
            //    FileDownloadName = "MySampleFile.pdf",
            //};
            //return fileResult;


            string filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "PDFFiles", "Sample.pdf");
            var fileResult = new PhysicalFileResult(filePath, "application/pdf")
            {
                FileDownloadName = "MySampleFile.pdf",
            };
            return fileResult;
        }



        //View Result
        public ViewResult About()
        {
            return View();
        }
    }
}
