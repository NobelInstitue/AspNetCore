﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace ASPIdentityDemo.Models
{
    ////public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    ////{
    ////    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
    ////        : base(options)
    ////    {
    ////    }
    //}
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser, ApplicationRole, string>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
    }
}
