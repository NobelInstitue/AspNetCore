﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace ModelBindingExample.Models
{
    public class User
    {
        //[Required(ErrorMessage = "Name is required.")]
        //[RegularExpression("^[a-zA-Z ]*$")]
        //[DisplayName("Name")]
        //public string? UserName { get; set; }
        //[Required(ErrorMessage = "Email is required.")]
        //[EmailAddress(ErrorMessage = "Invalid Email Address.")]
        //public string? UserEmail { get; set; }

        //public int age { get; set; }

        public int? Id { get; set; }
        public string? Name { get; set; }
        public string? Email { get; set; }
        public string? Password { get; set; }
        public string? Mobile { get; set; }
        public string? Gender { get; set; }
        public string? Country { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public List<string>? Hobbies { get; set; }
    }
}
