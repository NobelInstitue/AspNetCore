﻿namespace ConfigurationExample
{
    public class WeatherApiOption
    {
        public string? ClientID { get; set; }
        public string? ClientSecret { get; set; }
    }
}
