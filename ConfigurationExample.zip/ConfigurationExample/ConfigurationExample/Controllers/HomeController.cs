﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace ConfigurationExample.Controllers
{

    public class HomeController : Controller
    {
        private readonly IConfiguration _configuration;

        public HomeController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [Route("/")]
        public IActionResult Index()
        {
            //ViewBag.MyKey = _configuration["Mykey"];
            //ViewBag.MyAPIKey = _configuration.GetValue<string>("MyAPIKey", "This is default value");

            ViewBag.ClientID = _configuration.GetSection("weatherapi")["ClientID"];
            ViewBag.ClientSecret = _configuration.GetSection("weatherapi")["ClientSecret"];

            //ViewBag.ClientID = _configuration["weatherapi:ClientID"];
            //ViewBag.ClientSecret = _configuration["weatherapi:ClientSecret"];

            //IConfigurationSection weatherapisection = _configuration.GetSection("Weatherapi");

            //ViewBag.ClientID = weatherapisection["ClientID"];
            //ViewBag.ClientSecret = weatherapisection["ClientSecret"];

            // Get: Loads configuration values into a new options object
            //WeatherApiOption options = _configuration.GetSection("weatherapi").Get<WeatherApiOption>();
            //ViewBag.ClientID = options.ClientID;
            //ViewBag.ClientSecret = options.ClientSecret;

            //WeatherApiOption options = new WeatherApiOption();
            //_configuration.GetSection("Weatherapi").Bind(options);
            //ViewBag.ClientID = options.ClientID;
            //ViewBag.ClientSecret = options.ClientSecret;

            return View();
        }
    }
}
