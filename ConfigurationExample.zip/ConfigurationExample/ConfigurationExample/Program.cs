var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();
var app = builder.Build();

app.UseStaticFiles();
app.UseRouting();

//app.UseEndpoints(endpoints =>
//{
//    //endpoints.Map("/", async context =>
//    //    {
//    //        //await context.Response.WriteAsync(app.Configuration["Mykey"]);

//    //        //await context.Response.WriteAsync(app.Configuration.GetValue<string>("Mykey") + "\n");

//    //       // await context.Response.WriteAsync(app.Configuration.GetValue<decimal>("x", 23) + "\n");
//    //    });
//}
//);

app.MapControllers();


app.Run();
