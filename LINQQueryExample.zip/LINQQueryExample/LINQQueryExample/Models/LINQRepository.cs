﻿using Microsoft.EntityFrameworkCore;

namespace LINQQueryExample.Models
{
    public class LINQRepository:DbContext
    {
        public LINQRepository(DbContextOptions<LINQRepository> options) : base(options)
        {
        }

        public DbSet<Students> Students { get; set; }
        public DbSet<Branches> Branches { get; set; }
    }
}
