﻿using LINQQueryExample.Models;
using Microsoft.EntityFrameworkCore;

namespace LINQQueryExample.Models
{
    public class LINQQueryRepository
    {
        private readonly EntityFrameworkDbContext _context;
        public LINQQueryRepository(EntityFrameworkDbContext context)
        {
            _context = context;
        }
        public List<Students?> GetStudents()
        {
            string branchName = "Computer Science Engineering"; // Branch name filter
            string gender = "Female"; // Gender filter

            //LINQ Query Syntax to filter students by branch name and gender with eager loading
            //var filteredStudentsQS = (from Students in _context.Students
            //                         .Include(s => s.Branch) // Eager loading of the Branch property
            //                          where Students.Branch.BranchName == branchName && Students.Gender == gender
            //                          select Students).ToList();
            //return filteredStudentsQS;

            // Query Syntax to filter students by branch name and gender
            var filteredStudentsQS = (from Students in _context.Students
                                      where Students.Branch.BranchName == branchName && Students.Gender == gender
                                      select Students).ToList();
            return filteredStudentsQS;


            // LINQ Method Syntax to filter students by branch name and gender with eager loading
            //var filteredStudents = _context.Students
            //                              .Include(s => s.Branch) // Eager loading of the Branch property
            //                              .Where(s => s.Branch.BranchName == branchName && s.Gender == gender)
            //                              .ToList();
            // return filteredStudents;
        }
        public List<Students?> GetSortedStudents()
        {
            var sortedStudentsQuerySyntax = (from Students in _context.Students
                                             orderby Students.Gender ascending, Students.EnrollmentDate descending
                                             select Students).ToList();
            // Sorting students by LastName ascending and EnrollmentDate descending using Method Syntax
            var sortedStudentsMethodSyntax = _context.Students
                                                    .OrderBy(s => s.Gender) // Primary sort by Gender in ascending order
                                                    .ThenByDescending(s => s.EnrollmentDate) // Secondary sort by EnrollmentDate in descending order
                                                    .ToList();
            return sortedStudentsMethodSyntax;
        }

        public void GetGroupedStudents()
        {//// Grouping students by their Branch using Query Syntax
            var groupedStudentsQuerySyntax = (from Students in _context.Students
                                                     .Include(s => s.Branch) // Eager loading of the Branch property
                                              group Students by Students.Branch.BranchName into studentGroup //Group Students by BranchName into studentGroup
                                              select new
                                              {
                                                  // studentGroup.Key is the BranchName in this case
                                                  BranchName = studentGroup.Key,

                                                  // Count the number of students in each group
                                                  StudentCount = studentGroup.Count()
                                              }).ToList();
            //Grouping students by their Branch using Method Syntax
            var groupedStudentsMethodSyntax = _context.Students
                                                     .Include(s => s.Branch) // Eager loading of the Branch property
                                                     .GroupBy(s => s.Branch.BranchName) // Group students by BranchName
                                                     .Select(g => new
                                                     {
                                                         // g.Key is the BranchName in this case
                                                         BranchName = g.Key,

                                                         // Count the number of students in each group
                                                         StudentCount = g.Count()
                                                     })
                                                     .ToList();

           // return groupedStudentsMethodSyntax;
        }
    }
}
