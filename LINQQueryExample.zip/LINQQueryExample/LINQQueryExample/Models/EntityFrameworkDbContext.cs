﻿using Microsoft.EntityFrameworkCore;

namespace LINQQueryExample.Models
{
    public class EntityFrameworkDbContext:DbContext
    {
        public EntityFrameworkDbContext(DbContextOptions<EntityFrameworkDbContext> options) : base(options)
        {
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            // Disabling the EF Core Log
            // Display the generated SQL queries in the Console window
            // optionsBuilder.LogTo(Console.WriteLine, LogLevel.Information);
            // Configure the connection string
            //optionsBuilder.UseSqlServer(@"Server=localhost;Database=StudentDb;Trusted_Connection=True;TrustServerCertificate=True;");
        }
        // DbSet<Student> corresponds to the Students table in the database.
        // It allows EF Core to track and manage Student entities.
        public DbSet<Students> Students { get; set; }
        // DbSet<Branch> corresponds to the Branches table in the database.
        // It allows EF Core to track and manage Branch entities.
        public DbSet<Branches> Branches { get; set; }
    }
}
