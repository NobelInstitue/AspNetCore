﻿using LINQQueryExample.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LINQQueryExample.Controllers
{
    public class StudentController : Controller
    {
        private readonly LINQQueryRepository _Repository;
        private readonly EntityFrameworkDbContext _context;
        public StudentController(LINQQueryRepository Repository, EntityFrameworkDbContext context)
        {
            _Repository = Repository;
            _context = context;
        }
        public IActionResult Index()
        {

            //var filteredList = _Repository.GetStudents();

          _Repository.GetGroupedStudents();
            //if (filteredList.Any())
            //{

            //    return View(filteredList);
            //}
            //else
            //{
            //    // Output if no students match the filtering criteria
            //    return NotFound();
            //}
            return View();
        }
    }
}
