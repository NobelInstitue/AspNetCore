var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

app.Use(async (context, next) =>
{
    Microsoft.AspNetCore.Http.Endpoint? endpoint =
        context.GetEndpoint();
    if (endpoint != null)
    {
        await context.Response.WriteAsync($"Endpoint: {endpoint.DisplayName}\n");
    }
    await next(context);
});

app.UseRouting();

app.Use(async (context, next) =>
{
    Microsoft.AspNetCore.Http.Endpoint? endpoint =
        context.GetEndpoint();
    if (endpoint != null)
    {
        await context.Response.WriteAsync($"Endpoint: {endpoint.DisplayName}\n");
    }
    await next(context);
});

app.UseEndpoints(endpoints =>
{
    //enabling endpoints
    endpoints.Map("Map1", async (context) =>
    {
        await context.Response.WriteAsync("In Map1");
    });
    //endpoints.MapPost("Map1", async (context) =>
    //{
    //    await context.Response.WriteAsync("In Map1");
    //});

    //endpoints.MapGet("Map2", async (context) =>
    //{
    //    await context.Response.WriteAsync("In Map2");
    //});

    //Route Paramters
    //endpoints.Map("files/{filename}.{extension}", async (context) =>
    //{
    //    string? filename = (context.Request.RouteValues["filename"]).ToString();
    //    string? extension = (context.Request.RouteValues["extension"]).ToString();
    //    if (extension == "txt")

    //    {
    //        context.Response.WriteAsync($"In File-{filename}.{extension} ");
    //    }
    //    //context.Response.WriteAsync($"In File- ");
    //});
    //Default Paramter
    //endpoints.Map("employee/profile/{employeename=Yash}", async (context) =>
    //{
    //    string? empname = (context.Request.RouteValues["employeename"]).ToString();
    //    //string? extension = (context.Request.RouteValues["extension"]).ToString();

    //        context.Response.WriteAsync($"In employee profile ={empname} ");

    //    //context.Response.WriteAsync($"In File- ");
    //});
    //Optional parameter
    //endpoints.Map("product/details/{id?}", async (context) =>
    //{
    //    if (context.Request.RouteValues.ContainsKey("id"))
    //    {
    //        int? id = Convert.ToInt32(context.Request.RouteValues["id"]);
    //        context.Response.WriteAsync($"Product details-{id} ");
    //    }
    //    else
    //    {
    //        context.Response.WriteAsync($"Product details id is not supplied ");
    //    }
    //});

});
app.Run(async (context) => {
    await context.Response.WriteAsync($"Received path {context.Request.Path}");
});
app.Run();
