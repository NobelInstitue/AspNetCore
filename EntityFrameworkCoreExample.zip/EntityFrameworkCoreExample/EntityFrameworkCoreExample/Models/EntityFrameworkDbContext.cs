﻿using Microsoft.EntityFrameworkCore;

namespace EntityFrameworkCoreExample.Models
{
    public class EntityFrameworkDbContext:DbContext
    {
        public EntityFrameworkDbContext(DbContextOptions<EntityFrameworkDbContext> options):base(options)
        {

        }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Department> Departments { get; set; }
    }
}
