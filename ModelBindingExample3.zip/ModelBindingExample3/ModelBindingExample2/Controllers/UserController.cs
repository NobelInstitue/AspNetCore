﻿using Microsoft.AspNetCore.Mvc;
using ModelBindingExample2.Models;

namespace ModelBindingExample2.Controllers
{
    public class UserController : Controller
    {
        private static List<UserModel> Users = new List<UserModel>
        {
            new UserModel { Id = 1, Name = "Rakesh", Department = "IT", Gender = "Male", Salary = 1000 },
            new UserModel { Id = 2, Name = "Priyanka", Department = "IT", Gender = "Female", Salary = 2000  },
            new UserModel { Id = 3, Name = "Suresh", Department = "HR", Gender = "Male", Salary = 3000 },
            new UserModel { Id = 4, Name = "Hina", Department = "HR", Gender = "Female", Salary = 4000 },
            new UserModel { Id = 5, Name = "Pranaya", Department = "HR", Gender = "Male", Salary = 35000 },
            new UserModel { Id = 6, Name = "Pooja", Department = "IT", Gender = "Female", Salary = 2500 },
        };
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        [Route("users/{department}/{gender}/getdepartment")]
        public IActionResult GetDepartments([FromRoute(Name ="department")] string dept, string gender)
        {
            // Implementation to retrieve employees based on the Department
            var FilteredUsers = Users.Where(emp => emp.Department.Equals(dept, StringComparison.OrdinalIgnoreCase)).ToList();
            if (FilteredUsers.Count > 0)
            {
                return Ok(FilteredUsers);
            }
            return NotFound($"No Users Found with Department: {dept}");
        }

        [HttpGet]
        public IActionResult GetResource([FromHeader(Name = "Authorization")] string Authorisation)
        {
            // Implementation
            if (Authorisation == null)
            {
                return BadRequest("Authorization Token is Missing");
            }
            return Ok("Request Processed Successfully");
        }


        [HttpPost]
        public IActionResult CreateProduct([FromBody] List<Product> product)
        {
            // Add the product to the database or in-memory store
            // For demonstration, let's return the product back
            return Ok(product);
        }


    }
}
