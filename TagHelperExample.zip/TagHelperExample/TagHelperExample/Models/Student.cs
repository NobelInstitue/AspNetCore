﻿using System.ComponentModel.DataAnnotations;

namespace TagHelperExample.Models
{
    public class Student
    {
    
        public int StudentId { get; set; }
        [Required]
        public string? Name { get; set; }
        [Required]
        public string? Branch { get; set; }
        public string? Section { get; set; }
        public string? Gender { get; set; }
    }
}
