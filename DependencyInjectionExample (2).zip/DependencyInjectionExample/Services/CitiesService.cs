﻿using ServiceContract;

namespace Services
{
    public class CitiesService:ICitiesService
    {
        List<string> _cities;
        private Guid _serviceInstanceId;

        public Guid ServiceInstanceId
        {
            get
            {
                return _serviceInstanceId;
            }
        }
        public CitiesService()
        {
            _serviceInstanceId = Guid.NewGuid();
            _cities = new List<string>()
            {
                "Mumbai",
                "Pune",
                "Nasik",
                "Nagpur",
                "Solapur"

            };
        }
        public List<string> GetCities()
        {
            return _cities;
        }

        //public void Dispose()
        //{
        //    throw new NotImplementedException();
        //}
    }
}
