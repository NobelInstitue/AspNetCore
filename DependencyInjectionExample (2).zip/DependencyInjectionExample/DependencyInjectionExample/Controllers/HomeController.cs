﻿using Microsoft.AspNetCore.Mvc;
using Services;
using ServiceContract;

namespace DependencyInjectionExample.Controllers
{
    public class HomeController : Controller
    {
        private readonly ICitiesService _citiesService1;
        private readonly ICitiesService _citiesService2;
        private readonly ICitiesService _citiesService3;

        private readonly IServiceScopeFactory _serviceScopeFactory;
        //private readonly ICitiesService _citiesService;

        public HomeController(ICitiesService citiesservice1, ICitiesService citiesservice2, ICitiesService citiesservice3, IServiceScopeFactory serviceScopeFactory)
        {
            _citiesService1 = citiesservice1;//new CitiesService();
            _citiesService2 = citiesservice2;
            _citiesService3 = citiesservice3;
            _serviceScopeFactory = serviceScopeFactory;
        }

        [Route("/")]
        //public IActionResult Index([FromServices] ICitiesService _citiesService)
        public IActionResult Index()
        {
            List<string> cities = _citiesService1.GetCities();          
            ViewBag.InstanceId_CitiesService1=_citiesService1.ServiceInstanceId;
            ViewBag.InstanceId_CitiesService2 = _citiesService2.ServiceInstanceId;
            ViewBag.InstanceId_CitiesService3 = _citiesService3.ServiceInstanceId;

            using (IServiceScope scope = _serviceScopeFactory.CreateScope())
            {
                //inject cities service
                ICitiesService citiesService = scope.ServiceProvider.GetRequiredService<ICitiesService>();

                //DB work
                ViewBag.InstanceId_CitiesService_Inscope = citiesService.ServiceInstanceId;
            }//end of scope, calls CitiesService.Dispose() method



            return View(cities);
            
        }
    }
}
