﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace ADOCRUDOperations.Models
{
    public class Repository
    {
        private readonly string _connectionString;

        public Repository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DbConnectionString");
        }

        public List<Employee> GetAllEmployee()
        {
            List<Employee> employees = new List<Employee>();
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("sp_GetAllEmployee", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            employees.Add(new Employee
                            {
                                EmployeeId = (int)reader["EmployeeId"],
                                Name = reader["Name"].ToString(),
                                Email = reader["Email"].ToString(),
                                Position = reader["Position"].ToString(),
                                DepartmentId = (int)(reader["DepartmentId"]),
                                DepartmentName = reader["DepartmentName"].ToString()
                            });
                        }
                    }
                }
            }
            return employees;
        }

        // Create Item
        public void CreateEmployee(Employee employee)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("sp_CreateEmployee", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Name", employee.Name);
                    command.Parameters.AddWithValue("@Email", employee.Email);
                    command.Parameters.AddWithValue("@Position", employee.Position);
                    command.Parameters.AddWithValue("@DepartmentId", employee.DepartmentId);
                    command.ExecuteNonQuery();
                }
            }
        }

        public List<Department> GetAllDepartment()
        {
            Department department = null;
            List<Department> departments = new List<Department>();
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("GetAllDepartment", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var departmentId = reader["DepartmentId"] != DBNull.Value ? (int)reader["DepartmentId"] : 0;
                            var name = reader["Name"] != DBNull.Value ? reader["Name"].ToString() : string.Empty;

                            departments.Add(new Department
                            {
                                DepartmentId = (int)reader["DepartmentId"],
                                Name = reader["Name"].ToString()
                            });
                        }
                    }
                }
                return departments;
            }
        }

        //Get Item by ID
        public Employee GetEmployeeById(int id)
        {
            Employee employee = null;
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("GetEmployeeById", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@EmployeeId", id);
                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            employee = new Employee
                            {
                                EmployeeId = (int)reader["EmployeeId"],
                                Name = reader["Name"].ToString(),
                                Email = reader["Email"].ToString(),
                                Position = reader["Position"].ToString(),
                                DepartmentId = (int)reader["DepartmentId"],
                                DepartmentName = reader["DepartmentName"].ToString()
                            };
                        }
                    }
                }
            }
            return employee;
        }

        public string GetDepartmentById(int id)
        {
            Department department = null;
            string DeptName = string.Empty;
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("sp_GetDepartmentById", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@DepartmentId", id);
                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.FieldCount > 0)
                        {
                            if (reader.Read())
                            {
                                //department = new Department
                                //{                                
                                //DepartmentId = (int)reader["DepartmentId"],
                                DeptName = reader["Name"].ToString();
                                //};
                            }
                        }
                    }
                }
            }
            return DeptName;
        }

        // Update Item
        public void UpdateItem(Employee employee)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("sp_UpdateEmployee", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@EmployeeId", employee.EmployeeId);
                    command.Parameters.AddWithValue("@Name", employee.Name);
                    command.Parameters.AddWithValue("@Email", employee.Email);
                    command.Parameters.AddWithValue("@Position", employee.Position);
                    command.Parameters.AddWithValue("@DepartmentID", employee.DepartmentId);
                    command.ExecuteNonQuery();
                }
            }
        }

        // Delete Item
        public void DeleteItem(int id)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("SP_DeleteEmployee", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@EmployeeId", id);
                    command.ExecuteNonQuery();
                }
            }
        }
    }
}
