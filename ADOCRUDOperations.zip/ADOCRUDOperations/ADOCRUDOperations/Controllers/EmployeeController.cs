﻿using ADOCRUDOperations.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace ADOCRUDOperations.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly Repository _repository;
        public EmployeeController(Repository repository)
        {
            _repository = repository;
        }
        public IActionResult Index()
        {
            var items = _repository.GetAllEmployee();
            return View(items);
        }

        public IActionResult Create()
        {
            ViewData["Departments"] = _repository.GetAllDepartment();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Employee employee)
        {
            if (ModelState.IsValid)
            {
                _repository.CreateEmployee(employee);
                return RedirectToAction(nameof(Index));
            }

            return View(employee);
        }

        // Update Item
        public IActionResult Edit(int id)
        {
            var item = _repository.GetEmployeeById(id);
            if (item == null)
            {
                return NotFound();
            }
            // var department = _repository.GetDepartmentById(item.DepartmentId);
            var allDepartments = _repository.GetAllDepartment();
            ViewData["Departments"] = new SelectList(allDepartments, "DepartmentId", "Name", item.DepartmentId);

            return View(item);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, Employee employee)
        {
            if (id != employee.EmployeeId)
            {
                return NotFound();
            }
            employee.DepartmentName= _repository.GetDepartmentById(employee.DepartmentId);

            if (ModelState.IsValid)
            {
                _repository.UpdateItem(employee);
                return RedirectToAction(nameof(Index));
            }
            return View(employee);
        }

        // Delete an item
        public IActionResult Delete(int id)
        {
            var item = _repository.GetEmployeeById(id);
            if (item == null)
            {
                return NotFound();
            }
            return View(item);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            _repository.DeleteItem(id);
            return RedirectToAction(nameof(Index));
        }

        // View details of an item
        public IActionResult Details(int id)
        {
            var item = _repository.GetEmployeeById(id);
            if (item == null)
            {
                return NotFound();
            }
            return View(item);
        }
    }
}
