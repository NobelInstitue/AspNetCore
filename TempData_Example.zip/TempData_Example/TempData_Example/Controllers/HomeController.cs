using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Text.Json;
using TempData_Example.Models;

namespace TempData_Example.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            TempData["Name"] = "Pranaya";
            TempData["Age"] = 30;

            TempData.Keep("Name");
            TempData.Keep("Age");

            //string a = TempData["Age"] as string;
            //var a1 = TempData["Age"] as string;
            return RedirectToAction("Privacy");

            //return View();
        }

        public IActionResult Privacy()
        {
            TempData.Keep("Name");
            TempData.Keep("Age");

            Student student = new Student()
            {
                StudentId = 101,
                Name = "Dillip",
                Branch = "CSE",
                Section = "A",
                Gender = "Male"
            };
            //Student Address
            Address address = new Address()
            {
                StudentId = 101,
                City = "Mumbai",
                State = "Maharashtra",
                Country = "India",
                Pin = "400097"
            };
            //Creating the View model
            StudentDetailsViewModel studentDetailsViewModel = new StudentDetailsViewModel()
            {
                Student = student,
                Address = address,
                Title = "Student Details Page",
                Header = "Student Details",
            };
            TempData["StudentObject"] = student;
            TempData["AddressObject"] = address;
            return View();

        }

        public IActionResult About()
        {
            //var name = TempData.Peek("Name");
            //var age = TempData.Peek("Age");

            //if (TempData.ContainsKey("Name"))
            //{
            //    //Peek Method will read the data and preserve the key for next request
            //    ViewData["Name"] = TempData.Peek("Name");
            //}
            //if (TempData.ContainsKey("Age"))
            //{
            //    //Peek Method will read the data and preserve the key for next request
            //    ViewData["Age"] = TempData.Peek("Age");
            //}
           

            Student? student = new Student();
            if (TempData["StudentObject"] is string jsonStudent)
            {
                //Deserialize the Json Object to Actual Student Object
                student = JsonSerializer.Deserialize<Student>(jsonStudent);
                //You can use the Student
                // The following line keeps the data for another request

                TempData.Keep("StudentObject");
            }
            return Json(student);
           // return View();

          
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
