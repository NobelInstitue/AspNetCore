﻿using Microsoft.AspNetCore.Mvc;

namespace TempData_Example.Controllers
{
    public class StudentController : Controller
    {
        public IActionResult Index()
        {
            var name = TempData.Peek("Name");
            var age = TempData.Peek("Age");

            TempData.Keep("Name");
            TempData.Keep("Age");

            return RedirectToAction("About", "Home");
        }
    }
}
